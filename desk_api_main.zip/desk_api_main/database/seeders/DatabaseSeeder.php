<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Image;
use App\Models\Item;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */

    public function run()
    {
        Item::factory(25, [
            'title' => 'Продам кофе',
            'desc' => 'Продам кофе в большом количестве. ЗВОНИТЕ!!',
            'price' => random_int(1000, 3000),
        ])
        ->hasImages(3)
        ->create();
    }
}
