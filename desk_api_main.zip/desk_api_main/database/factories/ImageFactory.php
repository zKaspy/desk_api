<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Image;
use App\Models\Item;

class ImageFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */

    protected $model = Image::class;
    
    
    public function definition()
    {
        $images = array(
        "https://img.rudalle.ru/images/16/e9/72/16e972e30f914ebd88ecd4d6774dfa74_00000.jpg", 
        "https://img.rudalle.ru/images/13/7e/05/137e056be68d429badcd09bc59223aa4_00000.jpg", 
        "https://img.rudalle.ru/images/47/7b/66/477b66038ccd44858000c84acf9e7797_00000.jpg", 
        "https://img.rudalle.ru/images/19/09/7b/19097bd0a5af4c74a81d797d9fb8ede3_00000.jpg", 
        "https://sberdevices.s3pd01.sbercloud.ru/rndml-nlp/dalle-landing/xl/cat_clouds.png",
        "https://sberdevices.s3pd01.sbercloud.ru/rndml-nlp/dalle-landing/xl/photo_2021-11-01%2016.09.41.jpeg",
        "https://sberdevices.s3pd01.sbercloud.ru/rndml-nlp/dalle-landing/xl/photo_2021-11-01%2016.10.39.jpeg");

        $value = $images[array_rand($images, 1)];

        return [
            'img_url' => $value
        ];
    }
}
