<?php

namespace Tests\Controllers;
    
use Illuminate\Http\Response;
use Tests\TestCase;
use App\Models\Item;
use App\Models\Image;

class ItemControllerTest extends TestCase
{
    /*
     * первый тест. проверяем, что все объявления выводятся
     */
    public function testCorrectReturnDataAllItems() {
        $this->json('get', 'api/items')
         ->assertStatus(Response::HTTP_OK)
         ->assertJsonStructure(
             [
                 'data' => [
                     '*' => [
                         'id',
                         'title',
                         'desc',
                         'price',
                         'created_at',
                         'updated_at',
                         'images' => [
                             'id',
                             'img_url',
                             'item_id',
                             'created_at',
                             'updated_at'
                         ]
                     ]
                 ]
             ]
         );
    }

    public function testCorrectReturnDataAllItem() {
        $this->json('get', 'api/items/')
         ->assertStatus(Response::HTTP_OK)
         ->assertJsonStructure(
             [
                 'data' => [
                     '*' => [
                         'id',
                         'title',
                         'desc',
                         'price',
                         'created_at',
                         'updated_at',
                         'images' => [
                             'id',
                             'img_url',
                             'item_id',
                             'created_at',
                             'updated_at'
                         ]
                     ]
                 ]
             ]
         );
    }
}
