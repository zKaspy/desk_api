<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\ItemRequest;
use App\Http\Resources\ItemResource;
use App\Models\Item;
use App\Models\Image;

class ItemController extends Controller
{

    /**
     * @OA\Get(
     *      path="/api/items/",
     *      operationId="getItems",
     *      tags={"items"},
     *      summary="Получает список объявлений",
     *      description="Возвращает список всех объявлений",
     *      @OA\Response(
     *          response=200,
     *          description="Список объявлений получен"
     *      ),
     *       @OA\Response(
     *          response=404,
     *          description="Ошибка при получение объявлений"
     *       )
     *    )
     */

    public function index()
    {
        return ItemResource::collection(Item::with('images')->get());
    }

    /**
     * @OA\Post(
     *      path="/api/items/",
     *      operationId="postItem",
     *      tags={"items"},
     *      summary="Создает объявление",
     *      description="Создает объявление",
     *      @OA\Response(
     *          response=200,
     *          description="Объявление создано",
     *       ),  
     *      @OA\Response(
     *          response=404,
     *          description="Ошибка при создание объявления"
     *       )   
     *    )
     */

    public function store(ItemRequest $request)
    {
        $item = Item::create($request->validated());
        $images = [
            new Image(['img_url' => $request->screens_one]),
            new Image(['img_url' => $request->screens_two]),
            new Image(['img_url' => $request->screens_three])
        ];
        $item->images()->saveMany($images);
        return new ItemResource($item);
    }

    /**
     * @OA\Get(
     *      path="/api/items/{id}",
     *      operationId="getItem",
     *      tags={"items"},
     *      summary="Получает объявление",
     *      description="Возвращает объявление",
     *      @OA\Response(
     *          response=200,
     *          description="Объявление получено",
     *       ),     
     *      @OA\Response(
     *          response=404,
     *          description="Ошибка. Объявление не получено",
     *       ),
     *      @OA\Parameter(
     *          description="ID объявления",
     *          in="path",
     *          name="id",
     *          required=true,
     *          example="1",
     *              @OA\Schema(
     *                  type="integer",
     *                  format="int64"
     *          )
     *       )
     *    )
     */

    public function show(Item $item)
    {
        return new ItemResource($item);
    }
}
