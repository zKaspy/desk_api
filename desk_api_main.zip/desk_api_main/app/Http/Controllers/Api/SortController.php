<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Resources\ItemResource;
use App\Models\Item;

class SortController extends Controller
{

     /**
     * @OA\Get(
     *      path="/api/items/sort/{id}",
     *      operationId="getByDate",
     *      tags={"items"},
     *      summary="Сортирует объявление в зависимости от категории",
     *      description="Сортирует объявление в зависимости от категории",
     *      @OA\Response(
     *          response=200,
     *          description="Отсортированные объявления получены",
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="Ошибка при получение объявлений по категориям"
     *      ),
     *      @OA\Parameter(
     *          description="ID категории",
     *          in="path",
     *          name="id",
     *          required=true,
     *          example="1",
     *              @OA\Schema(
     *                  type="integer",
     *                  format="int64"
     *          )
     *       )
     *    )
     */

    public function getByDateAsc() {
        return ItemResource::collection(Item::getByDateAsc());
    }

    public function getByPriceDesc() {
        return ItemResource::collection(Item::getByPriceDesc());
    }
     
    public function getByPriceAsc() {
        return ItemResource::collection(Item::getByPriceAsc());
    }
    public function getByDateDesc() {
        return ItemResource::collection(Item::getByDateDesc());
    }
}
