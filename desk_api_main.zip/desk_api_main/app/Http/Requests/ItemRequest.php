<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ItemRequest extends FormRequest
{
    public function rules()
    {
        return [
            'title' => ['required', 'string', 'max:200'],
            'desc' => ['required', 'string', 'max:1000'],
            'price' => ['required'],
        ];
    }
}
