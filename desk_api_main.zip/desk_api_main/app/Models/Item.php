<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;

    public function images() {
        return $this->hasMany(Image::class)->orderBy('id', 'asc');
    }

    public function getByDateDesc() {
       return Item::orderBy('created_at', 'desc')->with('images')->paginate(10);
    }

    public function getByDateAsc() {
        return Item::orderBy('created_at', 'asc')->with('images')->paginate(10);
     }

    public function getByPriceDesc() {
        return Item::orderBy('price', 'desc')->with('images')->paginate(10);
    }
     
    public function getByPriceAsc() {
        return Item::orderBy('price', 'asc')->with('images')->paginate(10);
    }

    protected $fillable = ['title', 'desc', 'price'];

}
