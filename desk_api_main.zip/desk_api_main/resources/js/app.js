require('./bootstrap');

import { createApp } from 'vue'
import { createRouter, createWebHistory } from "vue-router"

import MainPage from './components/MainPage.vue';
import NotFound from './components/NotFound.vue';
import NewItem from './components/NewItem.vue';
import ShowItem from './components/ShowItem.vue';

const routes = [
    { 
        path: '/', 
        component: MainPage 
    },
    { 
        path: '/new', 
        component: NewItem 
    },
    { 
        path: '/items/:id',
        component: ShowItem 
    },
    { 
        path: '/:pathMatch(.*)*', 
        component: NotFound 
    }
]

const router = createRouter({
  history: createWebHistory(),
  routes, 
})

const app = createApp({})
app.use(router)
app.mount('#app')