<template>
    <div class="container-fluid">
        <p class="text-center py-1 fs-1">Доска объявлений</p>
        <div class="container py-2">
            <div class="d-flex align-items-center justify-content-end">
                <router-link to="/new" class="btn btn-primary">Создать объявление</router-link>
            </div>
        </div>
        <div class="container py-2">
            <h6>Сортировать по:</h6>
            <select class="form-select" aria-label="" v-model="category" @change="loadItems()">
                <option value="1">Сначала новые (по умолчанию)</option>
                <option value="2">Сначала старые</option>
                <option value="3">Сначала дешевые</option>
                <option value="4">Сначала дорогие</option>
            </select>
        </div>
        <div class="d-flex justify-content-center" v-if="loading">
            <div class="spinner-border" role="status"></div>
        </div>
        <div class="d-flex justify-content-center" v-if="error">
            <div>Данные не загрузились. Ошибка сервера :( [нет ответа от базы данных]</div>
        </div>
        <div class="d-flex justify-content-center" v-if="items.length == 0, error">
            <div>Объявления еще не созданы. Ваше объявление будет первым!</div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4" v-for="item in items" :key="item.id">
                <div class="card h-100">
                    <img :src="`${item.images[0].img_url}`" alt="" class="w-100 card-img-top" />
                    <div class="card-body">
                        <h3>{{ item.title }}</h3>
                        <p>{{ item.desc }}</p>
                        <p class="fw-bold">Цена: {{ item.price }} руб.</p>
                    </div>
                    <div class="card-footer col text-center">
                        <router-link :to="'/items/' + item.id" class="btn btn-primary">Открыть</router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <nav v-if="items.length != 0 && pagination.c_page <= 100">
        <ul class="pagination justify-content-center">
            <li class="page-item" v-for="page in pagination.all_pages">
                <a class="page-link" role="button" @click="loadItems(page)"
                    v-bind:class="{ active: page == pagination.c_page }">{{ page }}</a>
            </li>
        </ul>
    </nav>
</template>
<script>
export default {
    data() {
        return {
            items: [],
            loading: true,
            error: false,
            category: 1,
            pagination: {
                c_page: 1,
                all_pages: 0,
            },
        };
    },
    mounted() {
        this.loadItems(this.pagination.c_page);
    },
    methods: {
        loadItems(page) {
            this.loading = true;
            axios
                .get(`/api/items/sort/${this.category}?page=${page}`)
                .then((response) => {
                    (this.items = response.data.data),
                        (this.pagination.all_pages =
                            response.data.meta.last_page),
                        (this.pagination.c_page =
                            response.data.meta.current_page);
                })
                .catch(() => {
                    this.error = true;
                })
                .finally(() => (this.loading = false));
        },
    },
};
</script>
