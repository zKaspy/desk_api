<template>
    <div class="d-flex align-items-center justify-content-center flex-column vh-100 bg-primary">
        <h1 class="display-1 fw-bold text-white">404</h1>
        <h4 class="fw-bold text-white">Страница не найдена ;(</h4>
    </div>
</template>