<template>
    <div class="container">
        <p class="text-center py-1 fs-1">Создать объявление</p>
        <form>
            <div class="mb-3">
                <label for="item_title" class="form-label">Название объявления</label>
                <input type="text" class="form-control" id="item_title" v-model="title" />
                <div v-if="v$.title.$error" class="text-danger">
                    Поле обязательно для заполнения!
                </div>
                <div v-if="v$.title.$error" class="text-warning">
                    Не более 200 символов
                </div>
            </div>
            <div class="mb-3">
                <div class="form-group">
                    <label for="desc_item">Описание товара</label>
                    <textarea class="form-control" id="desc_item" rows="4" v-model="desc"></textarea>
                    <div v-if="v$.desc.$error" class="text-danger">
                        Поле обязательно для заполнения!
                    </div>
                    <div v-if="v$.desc.$error" class="text-warning">
                        Не более 1000 символов
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="screen_one" class="form-label">Ссылка на фотографию №1</label>
                <input type="text" class="form-control" id="screen_one" v-model="screens.one" />
                <div v-if="v$.screens.$error" class="text-danger">
                    Поле обязательно для заполнения!
                </div>
            </div>
            <div class="mb-3">
                <label for="screen_two" class="form-label">Ссылка на фотографию №2</label>
                <input type="text" class="form-control" v-model="screens.two" />
                <div v-if="v$.screens.$error" class="text-danger">
                    Поле обязательно для заполнения!
                </div>
            </div>
            <div class="mb-3">
                <label for="screen_three" class="form-label">Ссылка на фотографию №3</label>
                <input type="text" class="form-control" id="screen_three" v-model="screens.three" />
                <div v-if="v$.screens.$error" class="text-danger">
                    Поле обязательно для заполнения!
                </div>
            </div>
            <div class="mb-3">
                <label for="item_price" class="form-label">Цена товара</label>
                <input type="text" class="form-control" id="item_price" v-model="price" />
                <div v-if="v$.price.$error" class="text-danger">
                    Поле обязательно для заполнения!
                </div>
                <div v-if="v$.price.$error" class="text-warning">
                    Цена должна быть числом!
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-between">
                <button @click.prevent="createItem" class="btn btn-primary">
                    Создать
                </button>
                <router-link to="/" class="btn btn-primary">Вернуться назад</router-link>
            </div>
        </form>
    </div>
</template>
<script>
import useValidate from "@vuelidate/core";
import { required, maxLength, decimal } from "@vuelidate/validators";

export default {
    data() {
        return {
            v$: useValidate(),
            title: "",
            desc: "",
            screens: {
                one: "",
                two: "",
                three: "",
            },
            price: "",
        };
    },
    methods: {
        createItem(event) {
            event.preventDefault();
            let self = this;
            if (this.v$.$validate()) {
                axios
                    .post("/api/items", {
                        title: this.title,
                        desc: this.desc,
                        screens_one: this.screens.one,
                        screens_two: this.screens.two,
                        screens_three: this.screens.three,
                        price: this.price
                    })
                    .then(function (response) {
                        console.log(response);
                        self.$router.push('/');
                    })
                    .catch(() => {

                    });
            }
        },
    },
    validations() {
        return {
            title: { required, maxLength: maxLength(200) },
            desc: { required, maxLength: maxLength(1000) },
            screens: {
                one: { required },
                two: { required },
                three: { required },
            },
            price: { required, decimal },
        };
    },
};
</script>
