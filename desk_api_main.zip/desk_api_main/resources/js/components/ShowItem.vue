<template >
    <div class="container">
        <p class="text-center py-1 fs-1">Просмотр объявления</p>
        <form>
            <div class="mb-3">
                <label for="item_title" class="form-label">Название объявления</label>
                <input type="text" class="form-control" id="item_title" v-model="item.title" disabled />
            </div>
            <div class="mb-3">
                <div class="form-group">
                    <label for="desc_item">Описание товара</label>
                    <textarea class="form-control" id="desc_item" rows="4" v-model="item.desc" disabled></textarea>
                </div>
            </div>
            <div class="mb-3">
                <label for="item_price" class="form-label">Цена товара</label>
                <input type="text" class="form-control" id="item_price" v-model="item.price" disabled />
            </div>
            <div class="d-flex align-items-center justify-content-center">
                <router-link to="/" class="btn btn-primary">Вернуться назад</router-link>
            </div>
        </form>
    </div>
</template>
<script>
export default {
    data() {
        return {
            item: [],
            error: false
        };
    },
    mounted() {
        axios
            .get(`/api/items/${this.$route.params.id}`)
            .then((response) => {
                (this.item = response.data.data);
            })
            .catch(() => {
                this.$router.push('/');
            })
    }
};
</script>